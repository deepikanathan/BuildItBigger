package com.nanodegree.projects.javajoker;

public class Joker {
    public String tellJoke() {
        return "Microsoft gives you Windows, Linux gives you a hone!";
    }
}
